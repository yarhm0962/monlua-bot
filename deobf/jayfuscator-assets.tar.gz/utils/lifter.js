'use strict';
const a=require('./renamer');

function lua(v) {
  if (v===null||v===undefined)return 'nil';
  if (typeof v==='boolean')return v?'true':'false';
  if (typeof v==='number')return Number.isFinite(v)?String(v):'nil';
  if (typeof v==='string') {
    let s='"';
    for(const x of Buffer.from(v,'utf8')) {
      if(x===34||x===92)s+='\\'+String.fromCharCode(x);
      else if(x===10)s+='\\n';
      else if(x===13)s+='\\r';
      else if(x===9)s+='\\t';
      else if(x<32||x>=127)s+='\\'+String(x).padStart(3,'0');
      else s+=String.fromCharCode(x);
    }
    return s+'"';
  }
  if (v && v.kind==='environment')return '(getfenv and getfenv() or _ENV)';
  return 'nil';
}
function lift(root,options={}) {
  let n=0;
  function emit(proto,level=0) {
    if (level>64)throw Error('Prototype nesting exceeds 64');
    if (!proto||!Array.isArray(proto.instructions))throw Error('Invalid prototype');
    const constants=proto.constants||[];
    const children=proto.children||[];
    const lines=[];
    const indent=s=>'  '.repeat(level+1)+s;
    const reg=i=>'r['+Math.trunc(i)+']';
    const value=i=>lua(proto.constantsByIndex?.[Math.trunc(i)] ?? constants[Math.trunc(i)-1]);
    const up='up';
    const instructions=proto.instructions;
    const branch=new Set([9,12,14,20,27,29,30,35,36,44,47]);
    const branchy=instructions.some(i=>branch.has(+i[38]));
    const unknown=[];
    const nested=(index,caps)=>{
      const child=children[index];
      if(!child)throw Error('Missing closure '+index);
      const src=emit(child,level+2);
      if(!caps||!caps.length)return src;
      let bindings=[];
      caps.forEach((a,b)=>{
        const base=a['1']?'r':'up',index=Math.trunc(a['2']);
        bindings.push('['+b+'] = {get = function() return '+base+'['+index+'] end, set = function(x) '+base+'['+index+'] = x end}');
      });
      return '(function(r, up)\n'+ '  '.repeat(level+2)+'local cells = {'+bindings.join(', ')+'}\n'+
        '  '.repeat(level+2)+'local captured = setmetatable({}, {__index = function(_, x) return cells[x].get() end, __newindex = function(_, x, v) cells[x].set(v) end})\n'+
        '  '.repeat(level+2)+'return '+src.replace(/\bupvalues\b/g,'captured')+'\n'+
        '  '.repeat(level+1)+'end)(r, up)';
    };
    const raw=[];
    const jump=(instruction,index,condition)=>{
      const target=Math.trunc(+instruction[87])+1;
      if (target<1||target>instructions.length)throw Error('Jump target outside function: '+target);
      return condition?'if '+condition+' then pc = '+target+' else pc = '+(index+2)+' end':'pc = '+target;
    };
    for(let i=0;i<instructions.length;i++) {
      const q=instructions[i];
      const op=Math.trunc(+q[38]);
      const A=Math.trunc(+q[115]);
      const B=Math.trunc(+q[87]);
      const C=Math.trunc(+q[195]);
      const R=reg(A),RB=reg(B),RC=reg(C);
      let s='';
      switch(op) {
        case 0:s=R+' = {}';break;
        case 1:s=R+' = '+R+'()';break;
        case 2:s=R+' = '+R+'(unpackFn(r, '+(A+1)+', top))';break;
        case 3:s='return 1, 3, '+reg(A+2);break;
        case 4:s=R+' = '+RB+' + '+RC;break;
        case 5:s=R+'('+reg(A+1)+')';break;
        case 6:s=reg(A+1)+' = '+RB+'; '+R+' = '+RB+'['+value(C)+']';break;
        case 7:s='return '+R;break;
        case 8:s=R+' = '+RB+'['+RC+']';break;
        case 9:s=R+' = '+R+' + '+reg(A+2)+'; if ('+reg(A+2)+' > 0 and '+R+' <= '+reg(A+1)+') or ('+reg(A+2)+' <= 0 and '+R+' >= '+reg(A+1)+') then '+reg(A+3)+' = '+R+'; '+jump(q,i)+' else pc = '+(i+2)+' end';break;
        case 10:s=R+' = '+R+'('+reg(A+1)+')';break;
        case 11:s=R+' = '+R+'(unpackFn(r, '+(A+1)+', '+B+'))';break;
        case 12:s=jump(q,i,R+' ~= '+value(C));break;
        case 13:s=R+' = '+RB+' % '+value(C);break;
        case 14:s=jump(q,i,reg(C)+' ~= '+R);break;
        case 15:s=R+' = '+RB+'['+value(C)+']';break;
        case 16:s=R+' = '+RB+' * '+value(C);break;
        case 17:s=R+' = up['+B+']';break;
        case 18:s=R+' = '+nested(B,q[124]);break;
        case 19:s=R+'['+RB+'] = '+RC;break;
        case 20:s='if ('+reg(A+2)+' > 0 and '+R+' > '+reg(A+1)+') or ('+reg(A+2)+' <= 0 and '+R+' < '+reg(A+1)+') then '+jump(q,i)+' else '+reg(A+3)+' = '+R+'; pc = '+(i+2)+' end';break;
        case 21:s=R+' = table.concat((function() local x = {} for i = '+B+', '+C+' do x[#x+1] = r[i] end return x end)())';break;
        case 22:s=R+' = '+RB;break;
        case 23:throw Error('Unresolved opcode 23');
        case 24:s='do local x = packFn('+R+'(unpackFn(r,'+(A+1)+',top))) for i = '+A+', '+C+' do r[i] = x[i-'+A+'+1] end end';break;
        case 25:s='do local x = packFn('+R+'('+reg(A+1)+')) top = '+A+'+x.n-1 for i = 1,x.n do r['+A+'+i-1] = x[i] end end';break;
        case 26:s=R+' = '+(B!==0?'true':'false');break;
        case 27:s=jump(q,i,R+' == '+value(C));break;
        case 28:s=R+' = '+RB+' / '+value(C);break;
        case 29:s=jump(q,i,R+' < '+RC);break;
        case 30:s=jump(q,i,'not '+R);break;
        case 31:{
          const x=constants[B-1];
          s=R+' = '+(typeof x==='string' && /^[A-Za-z_][\w]*$/.test(x)?x:'((getfenv and getfenv() or _ENV)['+value(B)+'])');
          break;
        }
        case 32:s=R+'()';break;
        case 33:s=R+'['+value(B)+'] = '+value(C);break;
        case 34:s=R+' = '+value(B);break;
        case 35:s=jump(q,i);break;
        case 36:s=jump(q,i,R+' == true or ('+R+' ~= false and '+R+' ~= nil)');break;
        case 37:s=R+' = '+nested(B,[]);break;
        case 38:s=R+'(unpackFn(r,'+(A+1)+',top))';break;
        case 39:s=R+'(unpackFn(r,'+(A+1)+','+B+'))';break;
        case 40:s='do local x = packFn('+R+'(unpackFn(r,'+(A+1)+','+B+'))) top = '+A+'+x.n-1 for i = 1,x.n do r['+A+'+i-1] = x[i] end end';break;
        case 41:s=R+' = nil';break;
        case 42:s=R+' = '+RB+' - '+RC;break;
        case 43:s=R+' = '+RB+' + '+value(C);break;
        case 44:s='do local x = packFn('+R+'('+reg(A+1)+', '+reg(A+2)+')) for i = 1,'+C+' do r['+(A+2)+'+i] = x[i] end if r['+(A+3)+'] then r['+(A+2)+'] = r['+(A+3)+']; pc = '+(i+2)+' else '+jump(q,i)+' end end';break;
        case 45:s=R+'['+value(B)+'] = '+RC;break;
        case 46:s=R+' = #'+RB;break;
        case 47:s=jump(q,i,value(A)+' < '+RC);break;
        default:unknown.push(op);break;
      }
      raw.push(s);
    }
    if (unknown.length)throw Error('Unsupported VM opcodes '+[...new Set(unknown)].join(','));
    const prefix='  '.repeat(level);
    lines.push('function(...)');
    lines.push(prefix+'  local r, up = {}, upvalues');
    lines.push(prefix+'  local top = -1');
    lines.push(prefix+'  local unpackFn = unpack or table.unpack');
    lines.push(prefix+'  local packFn = table.pack or function(...) return {n = select("#", ...), ...} end');
    lines.push(prefix+'  local args = {...}');
    lines.push(prefix+'  for i = 0, select("#", ...) - 1 do if i < '+Math.trunc(proto.params||0)+' then r[i] = args[i+1] end end');
    if(!branchy) {
      for(let i=0;i<raw.length;i++) {lines.push(prefix+'  '+raw[i]);if ([3,7].includes(+instructions[i][38])) break;}
    } else {
      lines.push(prefix+'  local pc = 1');
      lines.push(prefix+'  while true do');
      raw.forEach((s,i)=>{
        lines.push(prefix+'    '+(i===0?'if':'elseif')+' pc == '+(i+1)+' then');
        lines.push(prefix+'      '+s);
        if (!branch.has(+instructions[i][38]) && ![3,7].includes(+instructions[i][38])) lines.push(prefix+'      pc = '+(i+2));
      });
      lines.push(prefix+'    else return end');
      lines.push(prefix+'  end');
    }
    lines.push(prefix+'end');
    return lines.join('\n');
  }
  const output=emit(root,0);
  return '-->> catboy hq deobfuscated this <<--\nreturn ('+output+')()\n';
}
module.exports={lift};
