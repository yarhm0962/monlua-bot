'use strict';
const {lift} = require('./lifter');
const {rename}=require('./renamer');

function literal(value) {
  if(value===null||value===undefined)return 'nil';
  if(typeof value==='boolean')return value?'true':'false';
  if(typeof value==='number')return Number.isFinite(value)?String(value):'nil';
  if(typeof value==='string') {
    let s='"';
    for(const b of Buffer.from(value,'utf8')) {
      if(b===34||b===92)s+='\\'+String.fromCharCode(b);
      else if(b===10)s+='\\n';
      else if(b===13)s+='\\r';
      else if(b===9)s+='\\t';
      else if(b<32||b>=127)s+='\\'+String(b).padStart(3,'0');
      else s+=String.fromCharCode(b);
    }
    return s+'"';
  }
  if(value?.kind==='environment')return '(getfenv and getfenv() or _ENV)';
  return 'nil';
}
function method(expr,key) {
  if(typeof key==='string'&&/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) return expr+'.'+key;
  return expr+'['+literal(key)+']';
}
function raw(proto) {
  const s=lift(proto).replace(/^-->> catboy hq deobfuscated this <<--\nreturn \(/,'');
  return s.replace(/\)\(\)\s*$/,'');
}
function rebuild(proto,settings={}) {
  let counter=0;
  const names=new Set();
  function unique(name) {
    name=(name||'value').replace(/[^A-Za-z0-9_]/g,'').replace(/^[^A-Za-z_]+/,'');
    if(!name||/^(?:nil|for|if|while|return|function|end|local|do|repeat|until|true|false|table|string|math)$/.test(name))name='value';
    let next=name,i=2;
    while(names.has(next)){next=name+i;i++;}
    names.add(next);
    return next;
  }
  function emit(proto,depth=0,closed=false) {
    if (depth>40)throw Error('Too deeply nested');
    if (!proto||!Array.isArray(proto.instructions))throw Error('Invalid function');
    const instructions=proto.instructions;
    const branching=new Set([9,12,14,20,27,29,30,35,36,44,47]);
    if(instructions.some(i=>branching.has(+i[38])))return raw(proto);
    const scope=new Map(),out=[];
    let toplist=null;
    const params=Math.trunc(proto.params||0);
    if(params) {
      for(let i=0;i<params;i++)scope.set(i,{expr:'arg'+(i+1),origin:'argument'});
    }
    const K=i=>proto.constantsByIndex?.[i]??proto.constants?.[i-1];
    const V=i=>literal(K(i));
    const item=i=>scope.get(i)||{expr:'nil'};
    const get=i=>item(i).expr;
    const set=(i,expr,origin)=>scope.set(i,{expr,origin});
    const hasName=i=>item(i).name;
    const name=(i,hint)=>{
      const n=unique(hint);
      out.push('local '+n+' = '+get(i));
      set(i,n,item(i).origin);
      return n;
    };
    const assign=(i,expr,hint,origin='temporary')=>{
      const n=unique(hint||'value');
      out.push('local '+n+' = '+expr);
      set(i,n,origin);
      return n;
    };
    const text=(a,b)=>get(a)+'('+b.map(get).join(', ')+')';
    const field=(v,k)=>method(v,k);
    const args=(a,b)=>{let s=[];for(let i=a;i<=b;i++)s.push(get(i));return s;};
    const hint=(func,argv)=>{
      if(func.kind==='method') {
        const m=func.key;
        if(m==='HttpGet')return 'source';
        if(m==='GetService'&&argv.length>=1) {
          const k=argv[0].replace(/^['"]|['"]$/g,'');
          return /^[\w]+$/.test(k)?k[0].toLowerCase()+k.slice(1):'service';
        }
        if(m==='WaitForChild'||m==='FindFirstChild'||m==='FindFirstChildOfClass') {
          const k=argv[0]?.replace(/^['"]|['"]$/g,'')||'object';
          return /^[\w]+$/.test(k)?k[0].toLowerCase()+k.slice(1):'object';
        }
        if(m==='CreateWindow')return 'window';
        if(m==='AddTab')return 'tab';
        if(m==='CreateToggle'||m==='AddToggle')return 'toggle';
        if(m==='CreateButton'||m==='AddButton')return 'button';
        if(m==='CreateSlider'||m==='AddSlider')return 'slider';
        if(m==='Connect')return 'connection';
        if(m==='GetChildren')return 'children';
        if(m==='GetPlayers')return 'players';
        if(m==='GetMouse')return 'mouse';
        return m[0].toLowerCase()+m.slice(1)+'Result';
      }
      const s=func.expr;
      if(s==='loadstring')return 'chunk';
      if(/\bchunk\d*$/.test(s))return 'library';
      if(s==='Instance.new') {
        let k=argv[0]?.replace(/^['"]|['"]$/g,'')||'instance';
        return /^[\w]+$/.test(k)?k[0].toLowerCase()+k.slice(1):'instance';
      }
      if(/\.fromOffset|\.fromScale|UDim2/.test(s))return 'size';
      return 'result';
    };
    const call=(A,last,splat=false,discard=false)=>{
      const f=item(A);
      let argv=args(A+1,last);
      if(splat && toplist) {
        const a=toplist;
        argv=args(A+1,Math.max(A,a.first-1));
        argv.push('unpackFn('+a.var+', 1, '+a.var+'.n)');
        toplist=null;
      }
      let expr;
      if(f.kind==='method'&&f.receiver && argv[0]===f.receiver) {
        const key=f.key;
        const head=/^[\w]+$/.test(key)?f.receiver+':'+key:f.expr;
        expr=head+'('+argv.slice(1).join(', ')+')';
      } else expr=f.expr+'('+argv.join(', ')+')';
      if(discard){out.push(expr);return {expr,hint:hint(f,f.kind==='method'&&argv[0]===f.receiver?argv.slice(1):argv)};}
      return {expr,hint:hint(f,f.kind==='method'&&argv[0]===f.receiver?argv.slice(1):argv)};
    };
    let jump=false;
    for(let pc=0;pc<instructions.length;pc++){
      const q=instructions[pc],op=Math.trunc(+q[38]);
      const A=Math.trunc(+q[115]),B=Math.trunc(+q[87]),C=Math.trunc(+q[195]);
      switch(op){
        case 0:{
          const nearby=instructions.slice(pc+1,pc+7).filter(e=>+e[115]===A && [+e[38]].some(v=>v===33||v===45));
          const keys=nearby.map(e=>K(Math.trunc(+e[87])));
          const base=keys.includes('Title')?'options':keys.includes('Main')?'tabs':keys.includes('Text')?'buttonOptions':'data';
          assign(A,'{}',base,'table');break;
        }
        case 1:{const a=call(A,A);assign(A,a.expr,a.hint,'call');break;}
        case 2:{const a=call(A,A,true);assign(A,a.expr,a.hint,'call');break;}
        case 3:{out.push('return 1, 3, '+get(A+2));return render(out,params,closed);}
        case 4:set(A,'('+get(B)+' + '+get(C)+')');break;
        case 5:call(A,A+1,false,true);break;
        case 6:{
          const rec=get(B),key=K(C);
          set(A+1,rec,'receiver');
          scope.set(A,{expr:field(rec,key),receiver:rec,kind:'method',key});break;
        }
        case 7:out.push('return '+get(A));return render(out,params,closed);
        case 8:set(A,get(B)+'['+get(C)+']');break;
        case 10:{const a=call(A,A+1);assign(A,a.expr,a.hint,'call');break;}
        case 11:{const a=call(A,B);assign(A,a.expr,a.hint,'call');break;}
        case 13:set(A,'('+get(B)+' % '+V(C)+')');break;
        case 15:set(A,field(get(B),K(C)));break;
        case 16:set(A,'('+get(B)+' * '+V(C)+')');break;
        case 17:set(A,'up['+B+']');break;
        case 18:{
          let cells=[];
          for (let i=0;i<(q[124]||[]).length;i++) {
            const v=q[124][i];
            if(v['1']) {
              const key=Math.trunc(v['2']);
              const val=get(key);
              const n=unique('captured');
              out.push('local '+n+' = '+val);
              cells.push('['+i+'] = {get = function() return '+n+' end, set = function(x) '+n+' = x end}');
            } else {
              const key=Math.trunc(v['2']);
              cells.push('['+i+'] = {get = function() return up['+key+'] end, set = function(x) up['+key+'] = x end}');
            }
          }
          const closure=raw(proto.children[B]);
          const n=unique('callback');
          out.push('local '+n+' = (function() local cells = {'+cells.join(', ')+'} local upvalues = setmetatable({}, {__index = function(_, x) return cells[x].get() end, __newindex = function(_, x, v) cells[x].set(v) end}) return '+closure+' end)()');
          set(A,n,'closure');break;
        }
        case 19:out.push(get(A)+'['+get(B)+'] = '+get(C));break;
        case 21:{const values=args(B,C);set(A,'('+values.join(' .. ')+')');break;}
        case 22:set(A,get(B),item(B).origin);break;
        case 24:{
          const a=call(A,A,true);
          if (C<A) {out.push(a.expr);break;}
          const vars=[];
          for(let i=A;i<=C;i++){const n=unique(i===A?a.hint:'result');vars.push(n);set(i,n,'call');}
          out.push('local '+vars.join(', ')+' = '+a.expr);break;
        }
        case 25:{const a=call(A,A+1);assign(A,a.expr,a.hint,'call');break;}
        case 26:set(A,B!==0?'true':'false');break;
        case 28:set(A,'('+get(B)+' / '+V(C)+')');break;
        case 31:{const v=K(B);set(A,typeof v==='string'&&/^[\w]+$/.test(v)?v:'(getfenv and getfenv() or _ENV)['+V(B)+']','global');break;}
        case 32:{const a=call(A,A,false,true);break;}
        case 33:out.push(field(get(A),K(B))+' = '+V(C));break;
        case 34:set(A,V(B),'constant');break;
        case 37:{
          const n=unique('helper');
          const c=proto.children[B];
          if(!c)throw Error('Missing closure '+B);
          out.push('local '+n+' = '+(c.instructions.some(i=>branching.has(+i[38]))?raw(c):emit(c,depth+1)));
          set(A,n,'closure');break;
        }
        case 38:{
          const a=call(A,A,true,true);break;
        }
        case 39:{call(A,B,false,true);break;}
        case 40:{
          const a=call(A,B);
          const n=unique(a.hint);
          out.push('local '+n+' = packFn('+a.expr+')');
          set(A,n+'[1]','call');
          toplist={var:n,first:A};
          break;
        }
        case 41:set(A,'nil');break;
        case 42:set(A,'('+get(B)+' - '+get(C)+')');break;
        case 43:set(A,'('+get(B)+' + '+V(C)+')');break;
        case 45:out.push(field(get(A),K(B))+' = '+get(C));break;
        case 46:set(A,'#'+get(B));break;
        default:throw Error('Optimizer unsupported straight-line opcode '+op);
      }
    }
    return render(out,params,closed);
  }
  function render(lines,params,closed) {
    const out=[];
    out.push('function(...)');
    out.push('  local unpackFn = unpack or table.unpack');
    out.push('  local packFn = table.pack or function(...) return {n = select("#", ...), ...} end');
    if(params>0)out.push('  local '+Array.from({length:params},(_,i)=>'arg'+(i+1)).join(', ')+' = ...');
    if(closed)out.push('  local up = upvalues');
    for(const s of lines)out.push('  '+s.replace(/\n/g,'\n  '));
    out.push('end');
    return out.join('\n');
  }
  const src=emit(proto,0);
  return '-->> catboy hq deobfuscated this <<--\nreturn ('+src+')()\n';
}
module.exports={rebuild};
