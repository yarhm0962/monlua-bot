'use strict';

const services = new Set([
  'Players','Lighting','TweenService','HttpService','ReplicatedStorage','ReplicatedFirst',
  'RunService','UserInputService','ContextActionService','MarketplaceService','SoundService',
  'CollectionService','TeleportService','StarterGui','StarterPlayer','StarterPack','Workspace',
  'ServerStorage','ServerScriptService','DataStoreService','Debris','TextService','Teams',
  'GuiService','PhysicsService','PathfindingService','BadgeService','InsertService',
  'ProximityPromptService','Chat','TextChatService','GroupService','LocalizationService',
  'Stats','VirtualInputManager','VirtualUser','TestService','MaterialService'
]);
const shortNames = {
  Players:'players',Lighting:'lighting',TweenService:'tweenService',HttpService:'httpService',
  ReplicatedStorage:'replicatedStorage',ReplicatedFirst:'replicatedFirst',RunService:'runService',
  UserInputService:'userInputService',ContextActionService:'contextActionService',
  MarketplaceService:'marketplaceService',SoundService:'soundService',
  CollectionService:'collectionService',TeleportService:'teleportService',
  StarterGui:'starterGui',StarterPlayer:'starterPlayer',StarterPack:'starterPack',
  Workspace:'workspaceService',ServerStorage:'serverStorage',ServerScriptService:'serverScriptService',
  DataStoreService:'dataStoreService',Debris:'debris',TextService:'textService',Teams:'teams',
  GuiService:'guiService',PhysicsService:'physicsService',PathfindingService:'pathfindingService',
  BadgeService:'badgeService',InsertService:'insertService',ProximityPromptService:'proximityPromptService',
  Chat:'chatService',TextChatService:'textChatService',GroupService:'groupService',
  LocalizationService:'localizationService',Stats:'stats',VirtualInputManager:'virtualInputManager',
  VirtualUser:'virtualUser',TestService:'testService',MaterialService:'materialService'
};
const objects = {
  ScreenGui:'screenGui',Frame:'frame',TextButton:'button',ImageButton:'imageButton',
  TextLabel:'textLabel',TextBox:'textBox',ImageLabel:'imageLabel',ScrollingFrame:'scrollingFrame',
  UIListLayout:'listLayout',UIGridLayout:'gridLayout',UICorner:'corner',UIStroke:'stroke',
  UIPadding:'padding',UIGradient:'gradient',Folder:'folder',Part:'part',MeshPart:'meshPart',
  Model:'model',Animation:'animation',Sound:'sound',BindableEvent:'bindableEvent',
  RemoteEvent:'remoteEvent',RemoteFunction:'remoteFunction',StringValue:'stringValue',
  NumberValue:'numberValue',BoolValue:'boolValue',IntValue:'intValue',ObjectValue:'objectValue',
  BillboardGui:'billboardGui',SurfaceGui:'surfaceGui',ProximityPrompt:'prompt',
  Tool:'tool',Humanoid:'humanoid',Motor6D:'motor',WeldConstraint:'weld',Attachment:'attachment'
};
const fields = {
  LocalPlayer:'localPlayer',PlayerGui:'playerGui',Character:'character',Humanoid:'humanoid',
  HumanoidRootPart:'rootPart',Head:'head',Backpack:'backpack',Mouse:'mouse',CurrentCamera:'camera',
  Camera:'camera',Handle:'handle',PrimaryPart:'primaryPart',DataStore:'dataStore',
  MouseButton1Click:'clickConnection',CharacterAdded:'characterAdded',
  RenderStepped:'renderConnection',Heartbeat:'heartbeatConnection'
};

function tokenize(source) {
  const result = [];
  let i = 0;
  while (i < source.length) {
    const start = i;
    const ch = source[i];
    if (/\s/.test(ch)) { i++; continue; }
    if (source.startsWith('--',i)) {
      i += 2;
      const m = /^(\[=*(\[))/.exec(source.slice(i));
      if (m) {
        const close = ']' + '='.repeat(m[1].length - 2) + ']';
        const end = source.indexOf(close, i + m[1].length);
        i = end < 0 ? source.length : end + close.length;
      } else { while (i < source.length && source[i] !== '\n') i++; }
      result.push({type:'comment',value:source.slice(start,i),start,end:i});
      continue;
    }
    if (ch === '"' || ch === "'") {
      i++;
      while (i < source.length) {
        if (source[i] === '\\') { i += 2; continue; }
        if (source[i++] === ch) break;
      }
      result.push({type:'string',value:source.slice(start,i),start,end:i});
      continue;
    }
    if (ch === '[') {
      const m = /^\[(=*)\[/.exec(source.slice(i));
      if (m) {
        const close = ']' + m[1] + ']';
        const end = source.indexOf(close,i+m[0].length);
        i = end < 0 ? source.length : end + close.length;
        result.push({type:'string',value:source.slice(start,i),start,end:i});
        continue;
      }
    }
    if (/[A-Za-z_]/.test(ch)) {
      i++; while (i < source.length && /[\w]/.test(source[i])) i++;
      result.push({type:'id',value:source.slice(start,i),start,end:i});
      continue;
    }
    if (/[0-9]/.test(ch)) {
      i++; while (i < source.length && /[\w.]/.test(source[i])) i++;
      result.push({type:'number',value:source.slice(start,i),start,end:i});
      continue;
    }
    i++;
    result.push({type:'symbol',value:ch,start,end:i});
  }
  return result.filter(t => t.type !== 'comment');
}
function meaningful(name) {
  return /^[a-z]{1,2}\d{0,4}$/.test(name) || /^[_OIl0-9]{5,}$/.test(name);
}
function lowerClass(name) {
  return name[0].toLowerCase() + name.slice(1);
}
function unwrapString(token) {
  if (!token || token.type !== 'string') return null;
  if (token.value[0] !== '"' && token.value[0] !== "'") return null;
  const body = token.value.slice(1,-1);
  return body.replace(/\\([\\"'nrt])/g,(_,c)=>({n:'\n',r:'\r',t:'\t'}[c] ?? c));
}
function getRight(tokens,index,source) {
  let end=index;
  let depth=0;
  while (end<tokens.length && end<index+100) {
    const t=tokens[end];
    if (end>index && depth===0 && /\n|;/.test(source.slice(tokens[end-1].end,t.start))) break;
    if (end>index && depth===0 && (t.value===';' || t.value==='local' || t.value==='end' || t.value==='then')) break;
    if ('([{'.includes(t.value)) depth++;
    if (')]}'.includes(t.value)) { if (depth===0) break;depth--; }
    end++;
  }
  return tokens.slice(index,end);
}
function suggest(tokens,name,known) {
  const values=tokens.map(t=>t.value);
  const head=values.join('');
  let m = /(?:game|[\w]+)(?::GetService\(|\.GetService\([\w]+,)["']([A-Za-z]+)["']\)/.exec(head);
  if (m && services.has(m[1])) return shortNames[m[1]]||lowerClass(m[1]);
  m=/Instance\.new\(["']([A-Za-z0-9]+)["']\)/.exec(head);
  if (m) return objects[m[1]]||lowerClass(m[1]);
  m=/(?::WaitForChild\(|:FindFirstChild\(|:FindFirstChildOfClass\()["']([\w ]+)["']\)/.exec(head);
  if (m) return fields[m[1]]||objects[m[1]]||null;
  if (/\.LocalPlayer\b/.test(head)) return 'localPlayer';
  if (/\.PlayerGui\b/.test(head)) return 'playerGui';
  if (/\.Character\b/.test(head)) return 'character';
  if (/\.CurrentCamera\b/.test(head)) return 'camera';
  if (/\.Mouse\b/.test(head)) return 'mouse';
  if (/^game$/.test(head)) return 'gameRef';
  if (/^workspace$/.test(head)) return 'world';
  if (/TweenInfo\.new\(/.test(head)) return 'tweenInfo';
  if (/Color3\.(fromRGB|new)\(/.test(head)) return 'color';
  if (/UDim2\.(new|fromOffset|fromScale)\(/.test(head)) return 'dimensions';
  if (/Vector3\.new\(/.test(head)) return 'position';
  if (/CFrame\.new\(/.test(head)) return 'targetCFrame';
  if (/Enum\.KeyCode\./.test(head)) return 'keyCode';
  if (values.length===1 && known.has(values[0]) && known.get(values[0])==='localPlayer') return 'playerReference';
  return null;
}
function rename(source) {
  const tokens = tokenize(source);
  const occurrences = new Map();
  const existing = new Set(tokens.filter(t=>t.type==='id').map(t=>t.value));
  const candidates = [];
  const known = new Map();
  for (let i=0;i<tokens.length;i++) {
    const t=tokens[i];
    if (t.type!=='id') continue;
    if (t.value!=='local') continue;
    let j=i+1;
    if (tokens[j]?.value==='function') {
      j++;
      const name=tokens[j]?.value;
      if (name && meaningful(name)) {
        const body=getRight(tokens,j+1,source).map(t=>t.value).join('');
        let hint=/SetCore\(["']ChatMakeSystemMessage/.test(body)?'sendSystemMessage':null;
        if (hint) candidates.push({name, hint});
      }
      continue;
    }
    if (tokens[j]?.type!=='id') continue;
    const name=tokens[j].value;
    if (tokens[j+1]?.value!== '=' || !meaningful(name)) continue;
    const rhs=getRight(tokens,j+2,source);
    const hint=suggest(rhs,name,known);
    if (hint) { candidates.push({name,hint});known.set(name,hint); }
  }
  for (const a of candidates) occurrences.set(a.name,(occurrences.get(a.name)||0)+1);
  const chosen=new Map();
  const used=new Set([...existing].filter(v=>!meaningful(v)));
  for (const a of candidates) {
    if (occurrences.get(a.name)!==1 || chosen.has(a.name)) continue;
    let name=a.hint;
    if (used.has(name)) {
      let n=2;
      while (used.has(name+n)) n++;
      name+=n;
    }
    used.add(name);
    chosen.set(a.name,name);
  }
  if (!chosen.size) return polish(source);
  const edits=[];
  for (let i=0;i<tokens.length;i++) {
    const a=tokens[i];
    if (a.type!=='id'||!chosen.has(a.value)) continue;
    const before=tokens[i-1]?.value;
    const after=tokens[i+1]?.value;
    if (before==='.'||before===':'||before==='::') continue;
    if (after===':'&&tokens[i+2]?.value===':') continue;
    if (before==='{'&&after==='=') continue;
    edits.push({start:a.start,end:a.end,text:chosen.get(a.value)});
  }
  let result=source;
  for(let i=edits.length-1;i>=0;i--) {
    const a=edits[i];result=result.slice(0,a.start)+a.text+result.slice(a.end);
  }
  return polish(result.replace(/(?:^|\n)[ \t]*do[ \t]*\r?\n[ \t]*end(?=\r?\n|$)/g,''));
}
function polish(source) {
  const labels = new Map();
  const proposed = new Map();
  const seen = new Set();
  const title = /\blocal\s+(options\d+)\s*=\s*\{\s*\}/g;
  let match;
  while ((match=title.exec(source))) {
    const part=source.slice(match.index,match.index+550);
    const escaped=match[1].replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    const found=new RegExp('\\b'+escaped+'\\.Title\\s*=\\s*(["\\\'])(.*?)\\1').exec(part);
    if (!found) continue;
    const value=found[2].replace(/[^a-zA-Z0-9 ]/g,' ').trim().split(/\s+/);
    if (value.length>6||!value.length)continue;
    let label=value.map((x,i)=>i===0?x[0].toLowerCase()+x.slice(1):x[0].toUpperCase()+x.slice(1)).join('');
    if(/^[0-9]/.test(label))label='item'+label;
    if(label.length>42)continue;
    labels.set(match[1],label);
    proposed.set(match[1],label+'Options');
  }
  const onClick=/\b(options\d+)\.Callback\s*=\s*(helper\d+)\b/g;
  while ((match=onClick.exec(source))) {
    if(labels.has(match[1]))proposed.set(match[2],labels.get(match[1])+'Callback');
  }
  const present=new Set(tokenize(source).filter(t=>t.type==='id').map(t=>t.value));
  const mapping=new Map();
  for (const [key,base] of proposed) {
    let name=base,n=2;
    while(present.has(name)||seen.has(name))name=base+(n++);
    mapping.set(key,name);seen.add(name);
  }
  if(!mapping.size)return source;
  const tokens=tokenize(source);
  const edits=[];
  for(let i=0;i<tokens.length;i++){
    const t=tokens[i];
    if(t.type!=='id'||!mapping.has(t.value)||['.',':'].includes(tokens[i-1]?.value))continue;
    edits.push({start:t.start,end:t.end,text:mapping.get(t.value)});
  }
  let result=source;
  for(let i=edits.length-1;i>=0;i--){const t=edits[i];result=result.slice(0,t.start)+t.text+result.slice(t.end);}
  return result;
}
module.exports = {rename, tokenize};
