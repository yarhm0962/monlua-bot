local f=assert(io.open(arg[1], 'rb'))
local source=f:read('*a')
f:close()
source=source:gsub('^```[%w]*%s*',''):gsub('%s*```%s*$','')
local changed=0
source,changed=source:gsub('return bj%(bv%(bg%(%)%)%,%{%}%,bg%(%)%)%(%)','return bv(bg())',1)
if changed==0 then source,changed=source:gsub('return by%(cw%(cg%(%)%)%,%{%}%,cg%(%)%)%(%)','return cw(cg())',1) end
if changed==0 then error('No known serializer entry point') end
local env={math=math,string=string,table=table,type=type,select=select,setmetatable=setmetatable,tonumber=tonumber,unpack=table.unpack,pairs=pairs,ipairs=ipairs,bit32=bit32}
env._ENV=env
env.getfenv=function()return env end
local code,msg
if loadstring and setfenv then
  code,msg=loadstring(source,'protected')
  if code then setfenv(code,env) end
else
  code,msg=load(source,'protected','t',env)
end
if not code then error('VM bootstrap syntax: '..tostring(msg)) end
local ok,root=pcall(code)
if not ok then error('VM bootstrap parse: '..tostring(root)) end
if type(root)~='table' then error('Expected root prototype, got '..type(root)) end
local escape=function(s)
  return '"'..s:gsub('[%z\1-\31\\"]',function(c)
    if c=='\\' then return '\\\\' end
    if c=='"' then return '\\"' end
    return string.format('\\u%04x',c:byte())
  end)..'"'
end
local function atom(v)
  if type(v)=='string' then return escape(v) end
  if type(v)=='boolean' then return tostring(v) end
  if type(v)=='number' then
    if v~=v or v==math.huge or v==-math.huge then return 'null' end
    return tostring(v)
  end
  if type(v)=='table' then return '{"kind":"environment"}' end
  if type(v)=='function' then return '{"kind":"function"}' end
  return 'null'
end
local seen={}
local function instruction(v)
  if type(v)~='table' then return '{}' end
  local r={}
  for k,x in pairs(v) do
    if type(k)=='number' then
      if type(x)=='table' then
        local list={}
        for j,n in pairs(x) do
          if type(j)=='number' and type(n)=='table' then
            local fields={}
            for l,a in pairs(n) do if type(l)=='number' then fields[#fields+1]=escape(tostring(l))..':'..atom(a) end end
            list[#list+1]='{'..table.concat(fields,',')..'}'
          end
        end
        r[#r+1]=escape(tostring(k))..':['..table.concat(list,',')..']'
      else r[#r+1]=escape(tostring(k))..':'..atom(x) end
    end
  end
  return '{'..table.concat(r,',')..'}'
end
local function prototype(v,depth)
  if depth>64 then error('Prototype nesting limit') end
  if seen[v] then return '{"recursive":true}' end
  seen[v]=true
  local a,b,c={},{},{}
  local d={}
  local ins,consts,children
  if type(v[53])=='table' and type(v[179])=='table' then
    ins,consts,children=v[53],v[93],v[179]
  else
    ins,consts,children=v[43],v[78],v[140]
  end
  if type(ins)=='table' then for i=1,#ins do a[#a+1]=instruction(ins[i]) end end
  if type(consts)=='table' then for i=1,#consts do b[#b+1]=atom(consts[i]) end for k,v in pairs(consts) do if type(k)=='number' then d[#d+1]=escape(tostring(k))..':'..atom(v) end end end
  if type(children)=='table' then local i=0 while children[i]~=nil do c[#c+1]=prototype(children[i],depth+1) i=i+1 if i>50000 then error('Too many nested prototypes') end end end
  return '{"params":'..atom(v[8] or v[115] or 0)..',"instructions":['..table.concat(a,',')..'],"constants":['..table.concat(b,',')..'],"constantsByIndex":{'..table.concat(d,',')..'},"children":['..table.concat(c,',')..']}'
end
local f=assert(io.open(arg[2], 'wb'))
f:write(prototype(root,0))
f:close()
