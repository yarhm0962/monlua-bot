'use strict';

function d(a) {
  a = a.trim().replace(/^```(?:lua|luau)?\s*\n?/, '').replace(/\n?```\s*$/, '');
  const b = /\bbi\s*=\s*Dc\s*\(\s*['"]([A-Za-z0-9+/=]{100,})['"]\s*\)/.exec(a);
  if (b) {
    const c = Buffer.from(b[1],'base64');
    const d = [];
    for (let e=0;e<c.length;e++) {
      if (c[e]!==255) {d.push(c[e]);continue;}
      if (++e>=c.length) throw Error('Invalid Base64/RLE escape');
      const f=c[e];
      if (f===0) d.push(255);
      else {
        if (++e>=c.length) throw Error('Invalid Base64/RLE repetition');
        for(let x=0;x<f;x++) d.push(c[e]);
      }
      if (d.length>128*1024*1024) throw Error('Payload exceeds 128 MiB');
    }
    return {data:Buffer.from(d),encoding:'base64-rle'};
  }
  const e = /\bbw\s*=\s*cs\s*\(\s*['"]([0-9a-fA-F]{100,})['"]\s*,\s*['"]\.\.['"]/.exec(a);
  if (e) return {data:Buffer.from(e[1],'hex'),encoding:'hex'};
  return null;
}
function e(a) {
  const b=[];
  let c=0;
  while (c<a.length) {
    let d=c;
    while (d<a.length && a[d]>=32 && a[d]<127) d++;
    if (d-c>=4) {
      const e=a.subarray(c,d).toString('utf8');
      const f=e.trim();
      if (f.length>=4) b.push({offset:c,value:f});
    }
    c=Math.max(c+1,d+1);
  }
  return b;
}
function f(a) {
  const b=e(a);
  const c=[];
  const d=new Set();
  for(const e of b) {
    if (d.has(e.value)) continue;
    d.add(e.value);
    c.push(e);
  }
  return {bytes:a.length,strings:c,stringsFound:c.length};
}
function x() {
  const a=process.argv.slice(2);
  if (!a.length||a.includes('--help')) {
    process.stdout.write('Usage: node deobf.js input.lua -o recovered.lua [--lua lua5.1.exe] [--ir file.json] [--binary file.bin] [--strings file.txt]\n');
    process.stdout.write('Unpacks supported VM transports and renames recovered Lua without falsifying source recovery.\n');
    return;
  }
  const b=a.find((b,c)=>!b.startsWith('-')&&!['-o','--output','--ir','--binary','--strings','--lua'].includes(a[c-1]));
  if (!b) throw Error('Missing input file');
  const c=(b,c)=>a.includes(b)?a[a.indexOf(b)+1]:c;
  const x={output:c('-o',c('--output',b.replace(/\.[^.]+$/,'.deobfuscated.lua')))};
  x.source=require('node:fs').readFileSync(b,'utf8');
  if (!/\bjayfuscator\b/i.test(x.source)) throw Error('No Jayfuscator signature was found; refusing to rename unrelated Lua source.');
  x.decoded=d(x.source);
  if (!x.decoded) throw Error('Unsupported Jayfuscator encoding');
  x.report=f(x.decoded.data);
  x.ir=c('--ir',x.output+'.ir.json');
  x.binary=c('--binary',x.output+'.payload.bin');
  x.strings=c('--strings',x.output+'.strings.txt');
  require('node:fs').writeFileSync(x.binary,x.decoded.data);
  require('node:fs').writeFileSync(x.strings,x.report.strings.map(a=>a.offset.toString(16).padStart(8,'0')+' '+a.value).join('\n')+'\n');
  x.tree=null;
  x.lastError='';
  x.engines=c('--lua',process.env.LUA_BIN||'').trim();
  x.engines=x.engines?[x.engines]:process.platform==='win32'?['lua5.1.exe','lua.exe']:['lua','lua5.1','luatex'];
  for(const e of x.engines) {
    x.temp=require('node:fs').mkdtempSync(require('node:path').join(require('node:os').tmpdir(),'jay_'));
    x.json=require('node:path').join(x.temp,'tree.json');
    x.decoder=require('node:path').join(__dirname,'utils','decoder.lua');
    x.argv=/\b(?:luatex|texlua)(?:\.exe)?$/i.test(e)?['--luaonly',x.decoder,b,x.json]:[x.decoder,b,x.json];
    x.run=require('node:child_process').spawnSync(e,x.argv,{encoding:'utf8',timeout:20000,maxBuffer:8*1024*1024,windowsHide:true});
    if(x.run.status===0) {
      try {x.tree=JSON.parse(require('node:fs').readFileSync(x.json,'utf8'));}catch(e) {x.lastError=e.message;}
    } else x.lastError=(x.run.error?.message||x.run.stderr||'Lua parser failed').trim();
    require('node:fs').rmSync(x.temp,{recursive:true,force:true});
    if (x.tree)break;
  }
  x.data={version:'Jayfuscator V1.2.1',transport:x.decoded.encoding,...x.report};
  if (x.tree) {
    x.data.vm=x.tree;
    x.data.instructions=(function e(a) {return a.instructions.length+a.children.reduce((b,c)=>b+e(c),0);})(x.tree);
    x.data.prototypes=(function e(a) {return 1+a.children.reduce((b,c)=>b+e(c),0);})(x.tree);
  }
  require('node:fs').writeFileSync(x.ir,JSON.stringify(x.data,null,2));
  process.stdout.write('Extracted '+x.decoded.data.length+' bytes ('+x.decoded.encoding+'), '+x.report.stringsFound+' strings.\n');
  if (x.tree && x.tree.instructions[0] && '38' in x.tree.instructions[0]) {
    try {
      try {x.lua=require('./utils/optimizer.js').rebuild(x.tree);}
      catch(e) {x.lua=require('./utils/lifter.js').lift(x.tree);}
      x.lua=require('./utils/renamer.js').rename(x.lua);
      require('node:fs').writeFileSync(x.output,x.lua,'utf8');
      process.stdout.write('Lifted '+x.data.instructions+' instructions in '+x.data.prototypes+' prototypes: '+x.output+'\n');
      return;
    } catch(e) {x.lastError=e.message;}
  }
  process.stderr.write('No verified source generated. VM IR, binary payload, and strings were saved. '+(x.lastError||'This opcode profile is not yet supported.')+'\n');
  process.exitCode=2;
}
try {x();}catch(a) {console.error(a.message);process.exitCode=1;}
